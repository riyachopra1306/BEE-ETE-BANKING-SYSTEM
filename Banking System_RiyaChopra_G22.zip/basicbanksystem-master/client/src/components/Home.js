import React from 'react'
import '../App.css'

const Home = () => {
    return (
        <>
        <div className="home-page">
        <div className="home-div">
            <p className="h5">Welcome </p>
            <h1>To Our Banking System</h1>
            </div>
        </div>
        </>
    )
}

export default Home

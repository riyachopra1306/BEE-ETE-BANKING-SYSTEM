# basicbanksystem
# Mern App | Basic Banking System

Hi am Pratiksha Doke
I have created Basic Banking System application using MERN stack 

[![basicbanksystem](https://img.youtube.com/vi/1LBGdbHfSt8/0.jpg)](https://www.youtube.com/watch?v=1LBGdbHfSt8)

